<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ambohController extends Controller
{
    public function tambah(){
        return view('sijob.tambah');
    }
    public function store(Request $request){
        DB :: table('jobdesct')->insert([
           'nama' => $request -> nama,
            'job' => $request -> job
        ]);
        return redirect('/home/entrijob');
    }
    public function hapus($id){
        DB::table('jobdesct')->where('j_id',$id)->delete();

        return redirect('/home/entrijob');
    }
    public function edit($id){
        $dhabit = DB::table('jobdesct')->where('j_id',$id)->get();

        return view('sijob.edit',['jobdesct' => $dhabit ]);
    }
    public function update(Request $request, $id){
        DB::table('jobdesct')->where('j_id', $id)->update([
            'nama'=>$request->nama,
            'job'=>$request->job
        ]);
        return redirect('/home/entrijob');
    }
}
