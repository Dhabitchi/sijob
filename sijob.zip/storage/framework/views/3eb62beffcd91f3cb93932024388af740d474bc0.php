<?php $__env->startSection('content'); ?>

    <?php if(auth()->user()->role=='admin'): ?>
<a href="<?php echo e(route('tambah')); ?>" class="btn btn-primary">+ tambah data</a>
    <?php endif; ?>
<h2 class="text-center">Entri Job</h2>

<table class="table">
    <thead>
    <tr>
        <th scope="col">No</th>
        <th scope="col">Nama</th>
        <th scope="col">Job</th>
        <?php if(auth()->user()->role=='admin'): ?>
        <th scope="col">edit/hapus</th>
        <?php endif; ?>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $entrijob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($p->nama); ?></td>
        <td><?php echo e($p->job); ?></td>
        <?php if(auth()->user()->role=='admin'): ?>
        <td><a href="/entrijob/edit/<?php echo e($p -> j_id); ?>">edit</a>
            <a href="/entrijob/hapus/<?php echo e($p -> j_id); ?>">hapus</a> </td>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.haha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sijob\resources\views/sijob/entrijob.blade.php ENDPATH**/ ?>