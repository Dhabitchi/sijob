<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $jobdesct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form action="/entrijob/update/<?php echo e($p->j_id); ?>" method="post" >
        <?php echo e(csrf_field()); ?>

        <?php echo method_field('PATCH'); ?>
        <input type="hidden" name="id" value="<?php echo e($p->j_id); ?>"><br>
        Nama<input type="text" name="nama" required="#" value="<?php echo e($p->nama); ?>"><br>
        Job<input type="text" name="job" required="#" value="<?php echo e($p->job); ?>"><br>
        <input type="submit" value="Simpan Data">
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.haha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sijob\resources\views/sijob/edit.blade.php ENDPATH**/ ?>