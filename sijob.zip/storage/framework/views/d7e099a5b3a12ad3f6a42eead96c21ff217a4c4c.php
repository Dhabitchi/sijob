<?php $__env->startSection('content'); ?>


<form action="<?php echo e(route('store')); ?>" method="post" >
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('POST'); ?>
    Nama<input type="text" name="nama" required="#"><br>
    Job<input type="text" name="job" required="#"><br>
    <input type="submit" value="Simpan Data">
    <a href="<?php echo e(route('entrijob')); ?>" class="#">Kembali</a>

</form>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.haha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sijob\resources\views/sijob/tambah.blade.php ENDPATH**/ ?>