@extends('layouts.haha')
@section('content')

    @foreach($jobdesct as $p)
    <form action="/entrijob/update/{{$p->j_id}}" method="post" >
        {{ csrf_field() }}
        @method('PATCH')
        <input type="hidden" name="id" value="{{$p->j_id}}"><br>
        Nama<input type="text" name="nama" required="#" value="{{$p->nama}}"><br>
        Job<input type="text" name="job" required="#" value="{{$p->job}}"><br>
        <input type="submit" value="Simpan Data">
    </form>
    @endforeach


@endsection
