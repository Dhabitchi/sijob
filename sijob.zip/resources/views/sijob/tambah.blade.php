@extends('layouts.haha')
@section('content')


<form action="{{route('store')}}" method="post" >
    {{ csrf_field() }}
    @method('POST')
    Nama<input type="text" name="nama" required="#"><br>
    Job<input type="text" name="job" required="#"><br>
    <input type="submit" value="Simpan Data">
    <a href="{{route('entrijob')}}" class="#">Kembali</a>

</form>





@endsection
