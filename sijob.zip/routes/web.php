<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/home/entrijob', 'EntrijobController@index')->name('entrijob');
Route::get('/home/staff', 'hahaController@staff')->name('staff');
//Route::get('/entrijob/create', 'hahaController@tambah')->name('tambah');

//Route::get('/home/haha/entrijob', 'entrijobController@entrijob')->name('entrijob');

//route crud
Route::post('/sijob/entrijob', 'EntrijobController@index');
Route::get('/sijob/create', 'EntrijobController@create');
Route::get('/entrijob/tambah','EntrijobController@tambah')->name('tambah');
Route::post('/entrijob/store','EntrijobController@store')->name('store');

//amboh
Route::get('/entrijob/tambah', 'ambohController@tambah')->name('tambah');
Route::post('/home/entrijob/', 'ambohController@store')->name('store');
Route::get('/entrijob/hapus/{id}', 'ambohController@hapus');
Route::get('/entrijob/edit/{id}', 'ambohController@edit');
Route::patch('/entrijob/update/{id}', 'ambohController@update');

Auth::routes();

